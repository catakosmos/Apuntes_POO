public enum PowerState {
    ON,
    OFF
}
